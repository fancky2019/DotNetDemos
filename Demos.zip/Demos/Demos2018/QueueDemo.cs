﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demos.Demos2018
{
    class QueueDemo
    {
        public void Test()
        {
            Queue<int> queue = new Queue<int>();
        }
    }
}
