﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demos.Demos2018
{
    class LambdaTest
    {
        public void  Test()
        {

        }

        private void  LinqExtention()
        {
            List<int> list = new List<int>();
            //Predicate
            //list.Where()
        }
    }
}
