﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Threading.Tasks;

namespace Demos.Demos2019
{
   public class WebSocketServer
    {
    //    ClientWebSocket

     //   HttpListener
    }
}
