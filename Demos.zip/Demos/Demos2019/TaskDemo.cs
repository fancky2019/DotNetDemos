﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Demos.Demos2019
{
    class TaskDemo
    {
        public void  Test()
        {

        }
        private void TaskThreadCounts()
        {
            //ThreadPool.SetMaxThreads
        }
    }
}
